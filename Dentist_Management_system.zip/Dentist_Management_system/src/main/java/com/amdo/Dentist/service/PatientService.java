package com.amdo.Dentist.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdo.Dentist.repo.PatientRepository;
import com.amdo.entity.Patient;

@Service
public class PatientService {
	@Autowired
	private PatientRepository patientRepository;
	
	public Patient save(Patient p) {
		return patientRepository.save(p);
	}
	
	public List<Patient> getAll(){
		return patientRepository.findAll();
	}
	
	public Patient getById(int id) {
		return patientRepository.findById(id).get();
	}
	
}
