package com.amdo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentistApplication {
    public static void main(String[] args) {
        SpringApplication.run(DentistApplication.class, args);
    }
}
